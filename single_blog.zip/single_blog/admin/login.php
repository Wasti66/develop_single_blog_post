<?php
	
	require_once('class/function.php');
	$obj = new Blog();
	session_start();
	
	if(isset($_POST['admin_login_btn'])){
		$login_error = $obj->admin_login($_POST);
	}
	
	if(isset($_SESSION['id'])){
		header('location:index.php');
	}

?>

<!doctype html>
<html lang="en">
	  <head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
		<meta name="generator" content="Hugo 0.84.0">
		<title>Blog website adminpanal</title>

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">
		<!-- Style CSS -->
		<link rel="stylesheet" href="assets/css/style.css">
		<!-- Global CSS -->
		<link rel="stylesheet" href="assets/css/global.css">
		<!-- fontawesome CSS -->
		<link rel="stylesheet" href="assets/css/all.css">
		
	  </head>
	  <body>
		<section class="bg-light d-flex align-items-center vh-100">
		   <div class="container">
		     <div class="row justify-content-center">
			   <div class="col-md-4">
				 <?php 
				     if(isset($login_error)){ 
						 echo '<p class="alert alert-danger">'.$login_error.'</p>'; 
					 }
				   ?>
			     <div class="card shadow border-0">
				   <div class="card-header bg-info">
					  <h5 class="text-capitalize font-bold text-center font-weight-700 text-light">login now</h5> 
				   </div>
				   <div class="card-body">
				      <form action="" method="post">
					  
					    <div class="input-group mb-3">
						  <span class="input-group-text">
						    <i class="fa-solid fa-user"></i>
						  </span>
						  <input type="text" name="username" class="form-control box-shadow-none" placeholder="User Name">
						</div>
						
						<div class="input-group mb-3">
						  <span class="input-group-text">
						    <i class="fa-solid fa-lock"></i>
						  </span> 
						  <input type="password" name="password" class="form-control box-shadow-none" placeholder="User Password">
						</div>
						<div class="mb-3 d-flex">
						  <div class="form-check">
							<input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
							<label class="form-check-label small" for="flexCheckDefault">
							  Remember me
							</label>
						  </div>
						  <div class="ms-auto">
						    <a href="#" class="small text-decoration-none">Forgot password?</a>
						  </div>
						</div>
					    <input type="submit" name="admin_login_btn" class="form-control btn btn-info text-white" value="Login">
					 </form>	
				   </div>
				 </div>	
			   </div>
			 </div>
		   </div>
		</section>
		
		<!-- Optional JavaScript -->
		<!-- jQuery first, then Popper.js, then Bootstrap JS -->
		<script src="assets/js/jquery-3.6.0.min.js"></script>
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		
		
	  </body>
</html>








