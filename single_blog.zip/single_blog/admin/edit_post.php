<?php
	
	require_once('class/function.php');
	$obj = new Blog();
	
	if(isset($_GET['status'])){
		$get_id = $_GET['id'];
		if($_GET['status'] == 'edit'){
			$row = $obj->upDatepostvalue($get_id);
			$value = mysqli_fetch_assoc($row);
		}
	}
	
	if(isset($_POST['update_post'])){
		$update_msg = $obj->upDatepost($_POST);
	}
	
?>
<?php require_once('include/head.php'); ?>
	  <body>
		
		<?php require_once('include/header.php'); ?>
		
		<section>
		<div class="container-fluid">
		  <div class="row">
			<?php require_once('include/side_nav.php'); ?>

			<div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
			  <div class="row justify-content-center">
			    <div class="col-md-8">
				  <div class="card card-body shadow border-0 bg-light">
				    <h4 class="text-capitalize fw-blod">Update post</h4>
					<hr>
					<?php
						if(isset($update_msg)){
							echo $update_msg;
						}
					?>
					<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
					   <input type="hidden" name="update_post_id" value="<?php echo $value['id'];?>">
					   <div class="mb-3">
						  <label class="col-form-label">Title</label>
						  <input type="text" name="update_title" class="form-control box-shadow-none" value="<?php echo $value['title']; ?>">
					   </div>
					   <div class="mb-3">
						  <label class="col-form-label">Content</label>
						  <textarea type="text" name="update_content" rows="5" class="form-control box-shadow-none"><?php echo $value['content'];?></textarea>
					   </div>
					   <input type="submit" name="update_post" class="btn btn-info text-light mb-3" value="Change Images">
					</form>
				  </div>
				</div>
			  </div>
			</div>
			
		  </div>
		</div>
		
		</section>
		
		<?php require_once('include/footer.php'); ?>
		

		<?php require_once('include/script.php'); ?>








