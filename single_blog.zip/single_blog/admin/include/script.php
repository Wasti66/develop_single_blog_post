<!-- Optional JavaScript -->
		<!-- jQuery first, then Popper.js, then Bootstrap JS -->
		<script src="assets/js/dashboard.js"></script>
		<script src="assets/js/jquery-3.6.0.min.js"></script>
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		<script src="assets/js/summernote.min.js"></script>
		
	  </body>
</html>