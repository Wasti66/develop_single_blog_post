<footer class="bg-info p-2">
		   <div class="container">
		     <div class="row justify-content-md-end justify-content-center">
			   <div class="col-md-8 col-12 text-md-left text-center">
			     <p class="mb-0 text-capitalize text-light">&copy;all right reseved by Wazihatulla Wasti and Developed By : Wazihatulla Wasti</p>
			   </div>
			 </div>
		   </div>
		 </footer>