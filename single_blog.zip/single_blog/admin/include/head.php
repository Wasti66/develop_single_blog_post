<?php
	
	require_once('class/function.php');
	$obj = new Blog();
	session_start();
	if(!isset($_SESSION['id'])){
		header('location:login.php');
	}
	

?>

<!doctype html>
<html lang="en">
	  <head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
		<meta name="generator" content="Hugo 0.84.0">
		<title>Admin</title>

		<link rel="canonical" href="https://getbootstrap.com/docs/5.0/examples/dashboard/">

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">
		<!-- Style CSS -->
		<link rel="stylesheet" href="assets/css/style.css">
		<!-- Global CSS -->
		<link rel="stylesheet" href="assets/css/global.css">
		<!-- fontawesome CSS -->
		<link rel="stylesheet" href="assets/css/all.css">
		<!-- Custom styles for this template -->
		<link href="assets/css/dashboard.css" rel="stylesheet">
		<link href="assets/css/summernote.min.css" rel="stylesheet">
		
	  </head>