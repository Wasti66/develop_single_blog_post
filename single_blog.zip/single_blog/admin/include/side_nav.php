<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
			  <div class="position-sticky">
				 
				 <div class="card rounded-0">
				    <div class="accordion accordion-flush" id="accordionFlushExample">
					  <!-- ==== MASTER PART === -->
					  <div class="accordion-item p-3 text-decoration-none text-capitalize h6">
						<a href="index.php" class="active text-decoration-none text-dark">
						  <i class="fa-solid fa-gauge-high"></i></i> 
						  dashboard
						</a>
					  </div>
					  <!-- ==== category ==== -->
					  <div class="accordion-item">
						<h2 class="accordion-header" id="user_part">
						  <button class="accordion-button collapsed box-shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#flush-user" aria-expanded="false" aria-controls="flush-collapseThree">
							<p class="mb-0 font-weight-700 text-capitalize text-muted"><i class="fa-solid fa-bars me-2"></i>category</p>
						  </button>
						</h2>
						<div id="flush-user" class="accordion-collapse collapse" aria-labelledby="user_part" data-bs-parent="#accordionFlushExample">
						
						  <div class="accordion-body p-1">
						    <div class="card p-1 bg-info border-0">
							  <a href="add_category.php" class="text-decoration-none text-capitalize text-white font-weight-500 text-center">add category</a>
							</div>
						  </div>
						  
						  <div class="accordion-body p-1">
						    <div class="card p-1 mb-2 bg-info border-0">
							  <a href="manage_category.php" class="text-decoration-none text-capitalize text-white font-weight-500 text-center">manage category</a>
							</div>
						  </div>
						  
						</div>
					  </div>
					  
					  <!-- ==== Blog ==== -->
					  <div class="accordion-item">
						<h2 class="accordion-header" id="blog">
						  <button class="accordion-button collapsed box-shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#flush-blog" aria-expanded="false" aria-controls="flush-collapseThree">
							<p class="mb-0 font-weight-700 text-capitalize text-muted"><i class="fa-solid fa-box me-2"></i>blog</p>
						  </button>
						</h2>
						<div id="flush-blog" class="accordion-collapse collapse" aria-labelledby="blog" data-bs-parent="#accordionFlushExample">
						
						  <div class="accordion-body p-1">
						    <div class="card p-1 bg-info border-0">
							  <a href="add_blog.php" class="text-decoration-none text-capitalize text-white font-weight-500 text-center">add blog</a>
							</div>
						  </div>
						  
						  <div class="accordion-body p-1">
						    <div class="card p-1 mb-2 bg-info border-0">
							  <a href="manage_blog.php" class="text-decoration-none text-capitalize text-white font-weight-500 text-center">manage blog</a>
							</div>
						  </div>
						  
						</div>
					  </div>
					  <!-- ==== change password ==== -->
					  <div class="accordion-item">
					    <div class="accordion-header p-3" id="change_password">
						  <a href="change_password.php" class="text-capitalize fw-bold text-decoration-none text-dark">change password</a>
						</div>
					  </div>
					  
					</div>
				 </div>

			  </div>
			</nav>