<?php
	
	require_once('class/function.php');
	$obj = new Blog();
	
	$id = $_GET['id'];
	$assoc = $obj->category_show($id);
	$row = mysqli_fetch_assoc($assoc);
	
	if(isset($_POST['up_add_cat_btn'])){
		$cat_update_message = $obj->cat_update($_POST);
	}
	
?>

<?php require_once('include/head.php'); ?>
	  <body>
		
		<?php require_once('include/header.php'); ?>
		
		<section>
		<div class="container-fluid">
		  <div class="row">
			<?php require_once('include/side_nav.php'); ?>

			<div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
			  <div class="row justify-content-center">
			    <div class="col-md-8">
				  <div class="card card-body shadow border-0 bg-light">
				    <h4 class="text-capitalize fw-blod">Update category</h4>
					<hr>
					
				    <form action="" method="post">
					   <input type="hidden" name="up_category_id" value="<?php echo $row['id'];?>">
					   <?php
							if(isset($cat_update_message)){
								echo "<span class='text-success'>".$cat_update_message."</span>";
							}
					   ?>
					   <div class="mb-4 mt-4 row">
						  <label class="col-sm-3 col-form-label">Update Category</label>
						  <div class="col-sm-9">
							<input type="text" name="up_category_name" class="form-control box-shadow-none" value="<?php echo $row['category_name'];?>">
						  </div>
					   </div>
					   <div class="mb-3 row">
						  <label class="col-sm-3 col-form-label">Status</label>
						  <div class="col-sm-9">
							<div class="form-check">
							  <input class="form-check-input" type="radio" name="status" value="1" <?= $row['status'] == '1' ? 'checked':'' ?> >
							  <label class="form-check-label">
								Active
							  </label>
							</div>
							<div class="form-check">
							  <input class="form-check-input" type="radio" name="status" value="0" <?= $row['status'] == '0' ? 'checked':'' ?>>
							  <label class="form-check-label">
								Inactive
							  </label>
							</div>
						  </div>
					   </div>
					   <input type="submit" name="up_add_cat_btn" class="btn btn-info text-light mb-3" value="Save">
					</form>
				  </div>
				</div>
			  </div>
			</div>
			
		  </div>
		</div>
		
		</section>
		
		<?php require_once('include/footer.php'); ?>
		

		<?php require_once('include/script.php'); ?>








