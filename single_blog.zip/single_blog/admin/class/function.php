<?php

	class Blog{
		
		private $conn;
		
		public function __construct(){
			$host = "localhost";
			$user = "root";
			$password = "";
			$db_name = "blog";
			
			$this->conn = mysqli_connect($host,$user,$password,$db_name);
			
			if(!$this->conn){
				echo "Data base connection error!";
			}
		}
		
		public function admin_login($data){
			$username = $data['username'];
			$password = md5($data['password']);
			$admin_sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
			
			if(mysqli_query($this->conn,$admin_sql)){
				
				$return_data = mysqli_query($this->conn,$admin_sql);
				
				if(mysqli_num_rows($return_data) == 1){
					$row = mysqli_fetch_assoc($return_data);
					
					session_start();
					$_SESSION['id'] = $row['id'];
					$_SESSION['username'] = $row['username'];
					$_SESSION['name'] = $row['name'];
					$_SESSION['password'] = $row['password'];
					
					header('location: index.php');
					
				}else{
					$login_error = "Your user name or password invalid";
					return $login_error;
				}
				
			}else{
				die();
			}
			
		}
		
		public function dsiplayAdmin(){
			$display_admin = "SELECT * FROM users `name`";
			if(mysqli_query($this->conn,$display_admin)){
				$admin_return = mysqli_query($this->conn,$display_admin);
				return $admin_return;
			}
		}
		
		/* --- ==== admin add category ===== -- */
		public function add_category($add_category){
			$category_name = $add_category['category_name'];
			$statuss = $add_category['status'];
			
			$select = "SELECT * FROM add_category WHERE category_name='$category_name'";
			$select_qyery = mysqli_query($this->conn,$select);
			$select_rows = mysqli_num_rows($select_qyery);
			
			if($select_rows == 1){
				$add_cat_save = "<span class='alert alert-danger'>This category name allready send please new some one</span>";
				return $add_cat_save;
			}else{
				
				$category_insert_sql = "INSERT INTO add_category(category_name,status) VALUES('$category_name',$statuss)";
				if(mysqli_query($this->conn,$category_insert_sql)){
					$add_cat_save = "<span class='alert alert-success'>Add category save!</span>";
					return $add_cat_save;
				}
				
			}
				
				
		}
		
		/* --- ==== admin manage category ===== -- */
		public function manage_categroy(){
			$category_display = "SELECT * FROM add_category";	
			if(mysqli_query($this->conn,$category_display)){
				$category_display_return = mysqli_query($this->conn,$category_display);
				return $category_display_return;
			}
		}
		
		/* --- ==== admin manage category active status show ===== -- */
		public function activeCategory(){
			$active_category_sql = "SELECT * FROM add_category WHERE status=1";
			if(mysqli_query($this->conn,$active_category_sql)){
				$return_active_category = mysqli_query($this->conn,$active_category_sql);
				return $return_active_category;
			}
		}
		
		/* --- ==== admin manage category active status show ===== -- */
		public function CategoryactivePost($cat_id){
			$active_category_sql = "SELECT * FROM add_blog WHERE status=1 and cat_id=$cat_id ORDER by id DESC";
			if(mysqli_query($this->conn,$active_category_sql)){
				$return_active_category = mysqli_query($this->conn,$active_category_sql);
				return $return_active_category;
			}
		}
		
		public function activePost(){
			$active_category_sql = "SELECT * FROM add_blog WHERE status=1 ORDER by id DESC";
			if(mysqli_query($this->conn,$active_category_sql)){
				$return_active_category = mysqli_query($this->conn,$active_category_sql);
				return $return_active_category;
			}
		}
		
		/* --- ==== admin manage category show value ===== -- */
		public function category_show($category_show_id=''){
			$category_show_sql = "SELECT * FROM add_category WHERE id=$category_show_id";
			return mysqli_query($this->conn,$category_show_sql);
		}
		
		/* --- ==== admin manage category update ===== -- */
		public function cat_update($update_cat){
			$up_category_id = $update_cat['up_category_id'];
			$up_category_name = $update_cat['up_category_name'];
			$status = $update_cat['status'];
			
			$cat_update_sql = "UPDATE add_category SET category_name='$up_category_name',status='$status' WHERE id=$up_category_id";
			if(mysqli_query($this->conn,$cat_update_sql)){
				$cat_update_message = "Update successfully";
				return $cat_update_message;
			}
		}
		
		/* --- ==== admin manage category delete ===== -- */
		public function namage_category_delete($namage_category_delete){
			$manage_cat_sql = "DELETE FROM add_category WHERE id=$namage_category_delete";
			mysqli_query($this->conn,$manage_cat_sql);
		}
		
		/* --- ==== admin manage category active ===== -- */
		public function active($active_id){
			$active_sql = "UPDATE add_category SET status=1 WHERE id=$active_id";
			if(mysqli_query($this->conn,$active_sql)){
				$active_done = "Active done";
				return $active_done;
			}
		}
		
		/* --- ==== admin manage category inactive ===== -- */
		public function inactive($inactive_id){
			$active_sql = "UPDATE add_category SET status=0 WHERE id=$inactive_id";
			if(mysqli_query($this->conn,$active_sql)){
				$inactive_done = "Inactive done";
				return $inactive_done;
			}
		}
		
		/* --- ==== admin add post ===== -- */
		public function addPost($post_data){
			
			$cat_id = mysqli_real_escape_string($this->conn,$post_data['cat_id']);
			$title = mysqli_real_escape_string($this->conn,$post_data['title']);
			$content = mysqli_real_escape_string($this->conn,$post_data['content']);
			$status = mysqli_real_escape_string($this->conn,$post_data['status']);
			
			$images = $_FILES['images']['name'];
			$images_tmp = $_FILES['images']['tmp_name'];
			$images_size = $_FILES['images']['size'];
			$images_ext = pathinfo($images,PATHINFO_EXTENSION);
			
			if(empty($cat_id) or empty($title) or empty($content) or empty($images)){
				$error_post = "All field is required";
				return $error_post;
			}
			
			if($images_ext == 'jpg' || $images_ext == 'png' || $images_ext == 'jpeg' || $images_ext == 'JPG' || $images_ext == 'PNG'){
				
				if($images_size <= 5242880){
					
					$add_blog_sql = "INSERT INTO add_blog(cat_id,title,content,images,name,status) VALUES($cat_id,'$title','$content','$images','Wasti',$status)";
					if(mysqli_query($this->conn,$add_blog_sql)){
						move_uploaded_file($images_tmp,'../uploads/'.$images);
						$error_post = '<span class="mb-3 text-success">Add Post Save</span>';
						return $error_post;
					}
					
				}else{
					$error_post = "5 mb or equal";
					return $error_post;
				}
				
			}else{
				$error_post = "Only jpg and png file suppoted";
				return $error_post;
			}
			
		}
		
		/* --- ==== admin add blog manage psot ===== -- */
		public function postDisplay(){
			$psot_display_sql = "SELECT add_blog.*,add_category.category_name FROM add_blog INNER JOIN add_category ON add_blog.cat_id = add_category.id ORDER by id DESC";
			if(mysqli_query($this->conn,$psot_display_sql)){
				$psot_display_return = mysqli_query($this->conn,$psot_display_sql);
				return $psot_display_return;
			}
		}
		
		/* --- ==== admin add blog active ===== -- */
		public function post_active($post_active_id){
			$post_active = "UPDATE add_blog SET status=1 WHERE id=$post_active_id";
			if(mysqli_query($this->conn,$post_active)){
				$post_active_return = mysqli_query($this->conn,$post_active);
				return $post_active_return;
			}
		}
		
		/* --- ==== admin add blog inactive ===== -- */
		public function post_inactive($post_inactive_id){
			$post_inactive = "UPDATE add_blog SET status=0 WHERE id=$post_inactive_id";
			if(mysqli_query($this->conn,$post_inactive)){
				$post_inactive_return = mysqli_query($this->conn,$post_inactive);
				return $post_inactive_return;
			}
		}
		
		/* --- ==== admin add blog delete ===== -- */
		public function namage_post_delete($namage_add_delete){
			
			$catch_img = "SELECT * FROM add_blog WHERE id=$namage_add_delete";
			$delete_img_sql = mysqli_query($this->conn,$catch_img);
			$delete_img = mysqli_fetch_assoc($delete_img_sql);
			$deleteimg_data = $delete_img['images'];
			
			$manage_add_sql = "DELETE FROM add_blog WHERE id=$namage_add_delete";
			if(mysqli_query($this->conn,$manage_add_sql)){
				
				unlink("../uploads/".$deleteimg_data);
			}
		}
		
		/* --- ==== admin add blog post display id ===== -- */
		public function postimgedit($postimg_edit){
			$postimgedit_sql = "SELECT * FROM add_blog `images` WHERE id=$postimg_edit";
			if(mysqli_query($this->conn,$postimgedit_sql)){
				$postimgreturn = mysqli_query($this->conn,$postimgedit_sql);
				return $postimgreturn;
			}
		}
		
		/* --- ==== admin add blog post img change ===== -- */
		public function editpostimg($edit_psot_img){
			
			$post_img_id = $edit_psot_img['change_id'];
			$change_img = $_FILES['change_img']['name'];
			$change_tmp = $_FILES['change_img']['tmp_name'];
			$change_post_img_ext = pathinfo($change_img,PATHINFO_EXTENSION);
			
			if($change_post_img_ext == 'jpg' or $change_post_img_ext == 'png' or $change_post_img_ext == 'jpeg' or $change_post_img_ext == 'JPG' or $change_post_img_ext == 'PNG' or $change_post_img_ext == 'JPEG'){
				
				$updateimg_sql = "UPDATE add_blog SET images='$change_img' WHERE id=$post_img_id";
				if(mysqli_query($this->conn,$updateimg_sql)){
					move_uploaded_file($change_tmp,'../uploads/'.$change_img);
					//header('location:post_img_change.php');
					$up_img_return = "Update successfully";
					return $up_img_return;
				}
				
			}else{
				$up_img_return = "Only jpg and png file supported";
				return $up_img_return;
			}
			
		}
		
		/* --- ==== admin add blog post update value ===== -- */
		public function upDatepostvalue($updatePostvalue){
			$updatePostvalue_sql = "SELECT * FROM add_blog WHERE id=$updatePostvalue";
			if(mysqli_query($this->conn,$updatePostvalue_sql)){
				$updatePostvalue_sql_return = mysqli_query($this->conn,$updatePostvalue_sql);
				return $updatePostvalue_sql_return;
			}
		}
		
		/* --- ==== admin add blog post update  ===== -- */
		public function upDatepost($upDatepost){
			
			$update_post_id = $upDatepost['update_post_id'];
			$update_title = mysqli_real_escape_string($this->conn,$upDatepost['update_title']);
			$update_content = mysqli_real_escape_string($this->conn,$upDatepost['update_content']);
			//$status = $upDatepost['status'];
			$upDatepost_sql = "UPDATE add_blog SET title='$update_title',content='$update_content' WHERE id=$update_post_id";
			
			if(mysqli_query($this->conn,$upDatepost_sql)){
				header('location:manage_blog.php');
				$update_success = "Update post successfully";
				return $update_success;
			}
			
		}
		
		/* --- ==== admin blog Singlepost  ===== -- */
		public function singlePost($singlepostid){
			$singlePost_sql = "SELECT * FROM add_blog WHERE id=$singlepostid";
			if(mysqli_query($this->conn,$singlePost_sql)){
				$singlepost_return = mysqli_query($this->conn,$singlePost_sql);
				return $singlepost_return;
			}
		}
		
		public function searchValue($text){
			$search = "SELECT * FROM `add_blog` WHERE `content` LIKE '%$text%' OR `title` LIKE '%$text%' AND status=1 ORDER by id DESC";
			return mysqli_query($this->conn,$search);
		}
		
		/* --- ==== admin change password ===== -- */
		public function changePass($changepass){
			$users_sql = "SELECT * FROM users";
			$users_query = mysqli_query($this->conn,$users_sql);
			$users_assoc = mysqli_fetch_assoc($users_query);
			$old_pass = $users_assoc['password'];
			$old_email = $users_assoc['email'];
			
			$currentpass = md5($changepass['currentpass']);
			$newpass = md5($changepass['newpass']);
			$confirmpass = md5($changepass['confirmpass']);
			
			if($old_pass == $currentpass){
				
				if($newpass == $confirmpass){
					
					$update_pass_sql = "UPDATE users SET password='$newpass' WHERE email='$old_email'";
					if(mysqli_query($this->conn,$update_pass_sql)){
						return "Your password has been updated successfully";
					}
					
				}else{
					return "Your new password and confirm password is equal";
				}
				
				//return "Mile gace";
			}else{
				return "Your current password is wrong";
			}
			
		}
		
	}

?>