<?php
	
	require_once('class/function.php');
	$obj = new Blog();
	
	if(isset($_GET['status'])){
		$get_id = $_GET['id'];
		if($_GET['status'] == 'edit'){
			$row = $obj->postimgedit($get_id);
			$value = mysqli_fetch_assoc($row);
		}
	}
	
	if(isset($_POST['post_change_images'])){
		$success_msg = $obj->editpostimg($_POST);
	}
	
?>
<?php require_once('include/head.php'); ?>
	  <body>
		
		<?php require_once('include/header.php'); ?>
		
		<section>
		<div class="container-fluid">
		  <div class="row">
			<?php require_once('include/side_nav.php'); ?>

			<div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
			  <div class="row justify-content-center">
			    <div class="col-12">
				  <div class="card card-body shadow border-0 bg-light">
				    <h4 class="text-capitalize fw-blod">change post images</h4>
					<hr>
					<?php
						if(isset($success_msg)){
							echo $success_msg;
						}
					?>
					<form action="" method="post" enctype="multipart/form-data">
					   <input type="hidden" name="change_id" value="<?php echo $value['id'];?>">
					   <div class="mb-3 row">
						  <label class="col-sm-3 col-form-label">Images</label>
						  <input type="file" name="change_img" class="form-control box-shadow-none mb-2" value="<?php echo $value['images'];?>">
						  <img src="../uploads/<?php echo $value['images'];?>" style="width:100px;">
					   </div>
					   <input type="submit" name="post_change_images" class="btn btn-info text-light mb-3" value="Change Images">
					</form>
				  </div>
				</div>
			  </div>
			</div>
			
		  </div>
		</div>
		
		</section>
		
		<?php require_once('include/footer.php'); ?>
		

		<?php require_once('include/script.php'); ?>








