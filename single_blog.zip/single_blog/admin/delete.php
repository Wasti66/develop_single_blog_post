<?php
	
	require_once('class/function.php');
	$obj = new Blog();
	
	if(isset($_GET['status'])){
		$get_id = $_GET['id'];
		if($_GET['status'] == 'delete'){
			$obj->namage_category_delete($get_id);
			header('location:manage_category.php');
		}
	}
	
	if(isset($_GET['status'])){
		$get_id = $_GET['id'];
		if($_GET['status'] == 'delete'){
			$obj->namage_post_delete($get_id);
			header('location:manage_blog.php');
		}
	}
	
?>