
<?php
	
	//session_start();
	require_once('class/function.php');
	$obj = new Blog();
	if(isset($_POST['pass_change_btn'])){
		$msg = $obj->changePass($_POST);
	}
	
?>

<?php require_once('include/head.php'); ?>
	  <body>
		
		<?php require_once('include/header.php'); ?>
		
		<section>
		<div class="container-fluid">
		  <div class="row">
			<?php require_once('include/side_nav.php'); ?>

			<div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
			  <div class="row justify-content-center">
			    <div class="col-md-6">
				  <div class="card card-body bg-light border-0 shadow">
				    <?php
						if(isset($msg)){
							echo $msg;
						}
					?>
				    <h3 class="fw-bold text-capitalize mb-3">change password</h3>
					<form action="" method="post">
					  <div class="mb-3">
					    <input type="password" name="currentpass" class="form-control box-shadow-none" placeholder="Old Password">
					  </div>
					  <div class="mb-3">
					    <input type="password" name="newpass" class="form-control box-shadow-none" placeholder="New Password">
					  </div>
					  <div class="mb-3">
					    <input type="password" name="confirmpass" class="form-control box-shadow-none" placeholder="Confirm Password">
					  </div>
					  <input type="submit" name="pass_change_btn" class="btn btn-info box-shadow-none" value="Change Password">
					</form>  
				</div>
			  </div>
			</div>
			
		  </div>
		</div>
		
		</section>
		
		<?php require_once('include/footer.php'); ?>
		

		<?php require_once('include/script.php'); ?>








