<?php
	
	require_once('class/function.php');
	$obj = new Blog();
	
	$psot = $obj->postDisplay();
	
?>
<?php require_once('include/head.php'); ?>
	  <body>
		
		<?php require_once('include/header.php'); ?>
		
		<section>
		<div class="container-fluid">
		  <div class="row">
			<?php require_once('include/side_nav.php'); ?>

			<div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
			  <div class="row justify-content-center">
			    <div class="col-12">
				  <h5 class="text-capitalize fw-bold mb-4">manage post</h5>
				  
				  <div class="table-responsive shadow">
				    <table class="table text-center border table-hover">
					  <thead>
						<tr>
						  <th>SI NO</th>
						  <th>Category Name</th>
						  <th>Title</th>
						  <th>Content</th>
						  <th>Image</th>
						  <th>Status</th>
						  <th>Action</th>
						</tr>
					  </thead>
					  <tbody>
					  <?php while($display_post = mysqli_fetch_assoc($psot)){?>
						<tr>
						  <th><?php echo $display_post['id']; ?></th>
						  <td><?php echo $display_post['category_name']; ?></td>
						  <td><?php echo $display_post['title']; ?></td>
						  <td><?php echo $display_post['content']; ?></td>
						  <td>
						    <img src="../uploads/<?php echo $display_post['images']; ?>" class="w-4"><br>
							<a href="post_img_change.php?status=edit&&id=<?php echo $display_post['id']; ?>" class="small font-weight-700">Change Images</a>
						  </td>
						  
						  <!-- === active and inactive === -->
						  <td>
							<?php 
							
								if($display_post['status'] == 1){
									echo "<span class='text-success font-weight-700'>Active</span>";
								}else{
									echo "<span class='text-danger font-weight-700'>Inactive</span>";
								}
							?>
							<?php
							
								if($display_post['status'] == 1){?>
									<a class="btn btn-danger btn-sm box-shadow-none" href="active_inactive.php?inactive_post=<?php echo $display_post['id']; ?>"><i class="fa-solid fa-arrow-down"></i> Inactive</a>
									<?php
								}else{?>
									<a class="btn btn-success btn-sm box-shadow-none" href="active_inactive.php?active_post=<?php echo $display_post['id']; ?>"><i class="fa-solid fa-arrow-up"></i> Active</a>
									<?php
									
								}
							
							?>
						  </td>
						  
						  <td>
						    <a href="edit_post.php?status=edit&&id=<?php echo $display_post['id']; ?>" class="btn btn-warning btn-sm box-shadow-none text-capitalize"><i class="fa-regular fa-pen-to-square"></i> Edit</a>
						    <a class="btn btn-info btn-sm box-shadow-none text-capitalize" href="delete.php?status=delete&&id=<?php echo $display_post['id'];?>"><i class="fa-regular fa-trash-can"></i> delete</a>
						  </td>
						</tr>
					  <?php } ?>	
					  </tbody>
					</table>
				  </div>
				</div>
			  </div>
			</div>
			
		  </div>
		</div>
		
		</section>
		
		<?php require_once('include/footer.php'); ?>
		

		<?php require_once('include/script.php'); ?>








