<?php

	require_once('class/function.php');
	$obj = new Blog();
	
	if(isset($_GET['active'])){
		$id = $_GET['active'];
		$obj->active($id);
		header('location:manage_category.php');
	}elseif(isset($_GET['inactive'])){
		$id = $_GET['inactive'];
		$obj->inactive($id);
		header('location:manage_category.php');
	}
	
	if(isset($_GET['active_post'])){
		$id_post = $_GET['active_post'];
		$obj->post_active($id_post);
		header('location:manage_blog.php');
	}elseif(isset($_GET['inactive_post'])){
		$id_post = $_GET['inactive_post'];
		$obj->post_inactive($id_post);
		header('location:manage_blog.php');
	}

?>