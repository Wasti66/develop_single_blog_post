<?php
	
	require_once('class/function.php');
	$obj = new Blog();
	$active_category = $obj->activeCategory();
	
	if(isset($_POST['add_blog_btn'])){
		$post_error = $obj->addPost($_POST);
	}
	
?>

<?php require_once('include/head.php'); ?>
	  <body>
		
		<?php require_once('include/header.php'); ?>
		
		<section>
		<div class="container-fluid">
		  <div class="row">
			<?php require_once('include/side_nav.php'); ?>

			<div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
			  <div class="row justify-content-center">
			    <div class="col-md-10">
				  <div class="card card-body shadow border-0 bg-light">
					
				    <h4 class="text-capitalize fw-blod">add blog</h4>
					<hr>
					<?php
						if(isset($post_error)){
							echo '<span class="text-danger">'.$post_error.'</span>';
						}
					?>
				    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post"  enctype="multipart/form-data">
					   <select class="form-select mb-3 box-shadow-none mt-3" name="cat_id">
						  <?php while($row = mysqli_fetch_assoc($active_category)){?>
						     <option value="<?php echo $row['id']; ?>"><?php echo $row['category_name']; ?></option>
						  <?php } ?>
					   </select>
					   <div class="mb-3">
						  <label class="form-label">Title</label>
						  <input type="text" name="title" class="form-control box-shadow-none">
					   </div>
					   <div class="mb-3">
						  <label class="form-label">Content</label>
						  <textarea type="text" name="content" class="form-control box-shadow-none" rows="5"></textarea>
					   </div>
					   <div class="mb-3">
						  <label class="form-label">Images</label>
						  <input type="file" name="images" class="form-control box-shadow-none">
					   </div>
					   <div class="mb-3 row">
						  <label class="col-sm-3 col-form-label">Status</label>
						  <div class="col-sm-9">
							<div class="form-check">
							  <input class="form-check-input" type="radio" name="status" value="1">
							  <label class="form-check-label">
								Active
							  </label>
							</div>
							<div class="form-check">
							  <input class="form-check-input" type="radio" name="status" value="0">
							  <label class="form-check-label">
								Inactive
							  </label>
							</div>
						  </div>
					   </div>
					   <input type="submit" name="add_blog_btn" class="btn btn-info text-light mb-3 box-shadow-none" value="Save Post">
					</form>
					
				  </div>
				</div>
			  </div>
			</div>
			
		  </div>
		</div>
		
		</section>
		
		<?php require_once('include/footer.php'); ?>
	
		<?php require_once('include/script.php'); ?>
		








