<?php
	
	require_once('class/function.php');
	$obj = new Blog();
	if(isset($_POST['add_cat_btn'])){
		$success_msg = $obj->add_category($_POST);
	}

?>

<?php require_once('include/head.php'); ?>
	  <body>
		
		<?php require_once('include/header.php'); ?>
		
		<section>
		<div class="container-fluid">
		  <div class="row">
			<?php require_once('include/side_nav.php'); ?>

			<div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
			  <div class="row justify-content-center">
			    <div class="col-md-8">
				  <div class="card card-body shadow border-0 bg-light">
				    <h4 class="text-capitalize fw-blod">add category</h4>
					<hr>
					<?php
						if(isset($success_msg)){
							echo $success_msg;
						}
					?>
				    <form action="" method="post">
					   <div class="mb-4 mt-4 row">
						  <label class="col-sm-3 col-form-label">Add Category</label>
						  <div class="col-sm-9">
							<input type="text" name="category_name" class="form-control box-shadow-none">
						  </div>
					   </div>
					   <div class="mb-3 row">
						  <label class="col-sm-3 col-form-label">Radio</label>
						  <div class="col-sm-9">
							<div class="form-check">
							  <input class="form-check-input" type="radio" name="status" value="1">
							  <label class="form-check-label">
								Active
							  </label>
							</div>
							<div class="form-check">
							  <input class="form-check-input" type="radio" name="status" value="0">
							  <label class="form-check-label">
								Inactive
							  </label>
							</div>
						  </div>
					   </div>
					   <input type="submit" name="add_cat_btn" class="btn btn-info text-light mb-3" value="Save">
					</form>
				  </div>
				</div>
			  </div>
			</div>
			
		  </div>
		</div>
		
		</section>
		
		<?php require_once('include/footer.php'); ?>
		

		<?php require_once('include/script.php'); ?>








