<?php
	
	require_once('class/function.php');
	$obj = new Blog();
	$display = $obj->manage_categroy();
	
?>
<?php require_once('include/head.php'); ?>
	  <body>
		
		<?php require_once('include/header.php'); ?>
		
		<section>
		<div class="container-fluid">
		  <div class="row">
			<?php require_once('include/side_nav.php'); ?>

			<div class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
			  <div class="row justify-content-center">
			    <div class="col-md-8">
				  <h5 class="text-capitalize fw-bold mb-4">manage category</h5>
				  <?php
					if(isset($delete_msg)){
				  ?>
				    <span class="text-success"><?php echo $delete_msg; ?></span>
				  <?php } ?>
				  <div class="table-responsive shadow">
				    <table class="table text-center border table-hover">
					  <thead>
						<tr>
						  <th>SI NO</th>
						  <th>Category Name</th>
						  <th>Status</th>
						  <th>Action</th>
						</tr>
					  </thead>
					  <tbody>
					  <?php while($display_category = mysqli_fetch_assoc($display)){?>
						<tr>
						  <th><?php echo $display_category['id']; ?></th>
						  <td><?php echo $display_category['category_name']; ?></td>
						  
						  <!-- === active and inactive === -->
						  <td>
							<?php 
							
								if($display_category['status'] == 1){
									echo "<span class='text-success'>Active</span>";
								}else{
									echo "<span class='text-danger'>Inactive</span>";
								}
							?>
							<?php
							
								if($display_category['status'] == 1){?>
									<a class="btn btn-danger btn-sm box-shadow-none" href="active_inactive.php?inactive=<?php echo $display_category['id']; ?>"><i class="fa-solid fa-arrow-down"></i> Inactive</a>
									<?php
								}else{?>
									<a class="btn btn-success btn-sm box-shadow-none" href="active_inactive.php?active=<?php echo $display_category['id']; ?>"><i class="fa-solid fa-arrow-up"></i> Active</a>
									<?php
									
								}
							
							?>
						  </td>
						  
						  <td>
						    <a href="edit_category.php?id=<?php echo $display_category['id']; ?>" class="btn btn-warning btn-sm box-shadow-none text-capitalize"><i class="fa-regular fa-pen-to-square"></i> Edit</a>
						    <a class="btn btn-info btn-sm box-shadow-none text-capitalize" href="delete.php?status=delete&&id=<?php echo $display_category['id']; ?>"><i class="fa-regular fa-trash-can"></i> delete</a>
						  </td>
						</tr>
					  <?php } ?>	
					  </tbody>
					</table>
				  </div>
				</div>
			  </div>
			</div>
			
		  </div>
		</div>
		
		</section>
		
		<?php require_once('include/footer.php'); ?>
		

		<?php require_once('include/script.php'); ?>








