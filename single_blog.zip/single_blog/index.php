<?php require_once('header.php');?>
        
        <!-- Page content-->
        <div class="container mt-5 pt-5">
            <div class="row justify-content-center">
                <!-- Blog entries-->
                <div class="col-lg-7">
				
					<?php
						if(isset($_GET['search'])){
							$search = $_GET['search'];
							$search_value = $obj->searchValue($search);
							if(mysqli_num_rows($search_value) > 0){
							while($search_row = mysqli_fetch_assoc($search_value)){ ?>
								
								 <div class="card mb-4">
									<a href="post.php?id=<?php echo $search_row['id'];?>"><img class="card-img-top" src="uploads/<?php echo $search_row['images'];?>" alt="..." style="height:300px;"></a>
									<div class="card-body">
									   <h2 class="card-title"><?php echo $search_row['title'];?></h2>
									   <p class='card-text'><?php echo $search_row['content'];?></p>
									   <a class="btn btn-primary" href="post.php?id=<?php echo $search_row['id'];?>">Read more →</a>
									</div>
									<div class="card-footer d-flex">
									  <p class="mb-0"><?php echo $search_row['createtime'];?></p>
									  
									  <a href="#" class="ms-3">Post by: 
										<?php echo $search_row['name'];?>
									  </a>
									  
									</div>
								</div>
								
								<?php
							}
							}else{
								echo '<H1 class="text-danger fw-bold text-center"><i>NOT FOUND!</i></H1>';
							}
						}else{ ?>
							
				
                    <!-- Featured blog post-->
					<?php while($display_post = mysqli_fetch_assoc($post)){?>
					
                    <div class="card mb-4">
                        <a href="post.php?id=<?php echo $display_post['id'];?>"><img class="card-img-top" src="uploads/<?php echo $display_post['images'];?>" alt="..." style="height:300px;"></a>
                        <div class="card-body">
                           <h2 class="card-title"><?php echo $display_post['title'];?></h2>
                           <p class='card-text'><?= substr($display_post['content'],0,250) ?>.....</p>
                           <a class="btn btn-primary" href="post.php?id=<?php echo $display_post['id'];?>">Read more →</a>
                        </div>
						<div class="card-footer d-flex">
						  <p class="mb-0"><?php echo $display_post['createtime'];?></p>
						  
						  <a href="#" class="ms-3">Post by: 
						    <?php echo $display_post['name'];?>
						  </a>
						  
						</div>
                    </div>
					
					<?php } ?>
					
					<?php } ?>
                    
                </div>
               <?php require_once('side_nav.php');?>
            </div>
        </div>
        <?php require_once('footer.php');?>
