<?php

	require_once('admin/class/function.php');
	$obj = new Blog();
	$get_id = $_GET['id'];
	$row = $obj->singlePost($get_id);
	$single_post = mysqli_fetch_assoc($row);

?>

<?php require_once('header.php');?>

	<div class="container mt-5 pt-5">
	  <div class="row justify-content-center">
	    <div class="col-md-7">
		  <div class="card mb-4">
		    <a href="#!"><img class="card-img-top" src="uploads/<?php echo $single_post['images'];?>" style="height:300px;"></a>
			<div class="card-body">
			  <h2 class="card-title"><?php echo $single_post['title'];?></h2>
			  <p><?php echo $single_post['content']; ?></p>
			</div>
			<div class="card-footer d-flex">
			  <p class="mb-0"><?php echo $single_post['createtime'];?></p>
			  <a href="#" class="ms-3">Post by: 
				<?php while($display_name = mysqli_fetch_assoc($name)){ echo $display_name['name'];}?>
			  </a>
			</div>
		  </div>
		</div>
		<?php require_once('side_nav.php');?>
	  </div>
	</div>

<?php require_once('footer.php');?>