<?php

	require_once('admin/class/function.php');
	$obj = new Blog();
	$get_id = $_GET['id'];
	$category_id = $obj->CategoryactivePost($get_id);
	
?>

	<?php require_once('header.php');?>
		<div class="container mt-5 pt-5">
		  <div class="row justify-content-center">
		   
		    <div class="col-lg-7">
			  <?php while($display_cat = mysqli_fetch_assoc($category_id)){ ?>
			  <div class="card">
			    <a href=""><img class="card-img-top" src="uploads/<?php echo $display_cat['images'];?>" alt="..." style="height:300px;"></a>
				<div class="card-body">
				   <h2 class="card-title"><?php echo $display_cat['title'];?></h2>
				   <p class='card-text'><?php echo $display_cat['content'];?></p>
				   <a class="btn btn-primary" href="post.php?id=<?php echo $display_cat['id'];?>">Read more →</a>
				</div>
				<div class="card-footer d-flex">
				  <p class="mb-0"><?php echo $display_cat['createtime'];?></p>
				  
				  <a href="#" class="ms-3">Post by: 
					<?php echo $display_cat['name'];?>
				  </a>
			    		  
				</div>
			  </div>
			  <?php } ?>
			</div>
			<?php require_once('side_nav.php');?>
		  </div>
		</div>
	<?php require_once('footer.php');?>